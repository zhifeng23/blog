---
layout: post
title:  "Teach Girlfriend to make a Web Pages like Zhihu"
date:   2015-03-21 15:14:54
categories: Bootstrap
tags: BootStrap HTML CSS Zhihu
---

* content
{:toc}

My girlfriend is learning html and css recently. I told her to follow the video. Here, I recommend a video in Chinese that suite for fresh learners. The name of course is Getting HTML web pages dev in 8 hours ( 8小时学会HTML网页开发 ) . I watched this video at very first time. The teacher named Eighteen Swallows ( 燕十八 ) . He teached very clear even himself being on screen to show what is float or box-model.    




<!-- ![燕十八](http://7q5cdt.com1.z0.glb.clouddn.com/teach-girlfriend-html-18swallows.png) -->

Here is the site of the free online video.
[http://study.163.com/course/courseMain.htm?courseId=432008](http://study.163.com/course/courseMain.htm?courseId=432008)    

I did the detailed note about this course. You can read here: [http://wenku.baidu.com/view/aa136099f90f76c660371a35](http://wenku.baidu.com/view/aa136099f90f76c660371a35)   

Now I'll tell something happend today. She has watched the video above, and knows a little on BootStrap. So she wants to do some pages with BootStrap.    

We determined to copy the pages on [Zhihu](http://zhihu.com)   
Like this:   
![知乎zhihu](http://7q5cdt.com1.z0.glb.clouddn.com/teach-girlfriend-html-zhihu.jpg)   

I teached her [Boostrap](http://www.bootcss.com/) this afternoon. She has already got to read the docs and can code simple statics pages.   

She seems to enjoy Web Pages Design. Though she used to be a Graphic Designer. And now, she really works hard.

At last I'll show the works that we did together in 2 hours. It's unfinished. I guess she will do it later. It's a nice weekend, isn't it?   

[to see Copy Zhihu, click here](http://gaohaoyang.github.io/test/bootstrap-zhihu/)   

screenshot of copy Zhihu:
![Copy Zhihu](http://7q5cdt.com1.z0.glb.clouddn.com/teach-girlfriend-html-CopyZhihu.jpg)
